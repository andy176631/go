#!/usr/bin/env bash

OUTPUT_DIR="./pods-1-20"
mkdir -p "${OUTPUT_DIR}"

for i in $(seq 1 20); do
  POD_NAME="pod${i}"
  FILE="${OUTPUT_DIR}/${POD_NAME}.yaml"

  cat > "${FILE}" <<EOF
apiVersion: v1
kind: Pod
metadata:
  name: ${POD_NAME}
spec:
  terminationGracePeriodSeconds: 0
  containers:
  - name: ${POD_NAME}-container
    image: registry.k8s.io/pause:3.9
    volumeMounts:
EOF

  # 加入 20 個 volumeMounts
  for v in $(seq 1 20); do
    cat >> "${FILE}" <<EOF
    - name: vol${v}
      mountPath: /mnt/vol${v}
EOF
  done

  # 加入 volumes 定義
  cat >> "${FILE}" <<EOF
  volumes:
EOF

  for v in $(seq 1 20); do
    cat >> "${FILE}" <<EOF
  - name: vol${v}
    emptyDir: {}
EOF
  done

  echo "Generated ${FILE}"
done

echo "All YAML files generated in ${OUTPUT_DIR}"
