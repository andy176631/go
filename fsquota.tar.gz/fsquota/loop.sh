#!/bin/bash
while true; do
  kubectl apply -f pods-1-20 & kubectl delete -f pods-21-40 --ignore-not-found
  sleep 56
  kubectl apply -f pods-21-40 & kubectl delete -f pods-1-20 --ignore-not-found	
  sleep 56
done
